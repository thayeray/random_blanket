library(maptools)  		
library(spdep)   		
library(sm)   			
x = readShapePoly("CA_Polygons")  	
growth = x$GROWTH
gal = read.gal("caQueen.gal", region.id = x$MYID)   	
w = nb2listw(gal)  		
mt = moran.test(growth, w, alternative = "two.sided")
